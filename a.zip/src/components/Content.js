function Header() {
  return (
    <p>
      Day la 1 component, ten la Header
    </p>
  );
}

export default Header;
